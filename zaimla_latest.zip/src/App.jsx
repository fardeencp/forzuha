import { Routes, Route } from 'react-router-dom'
import Landing from './pages/Landing'
import Admin from './pages/Admin'
import Login from './pages/Login'
import Careers from './pages/Careers'

export default function App(){
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/careers" element={<Careers />} />
      <Route path="/admin" element={<Admin />} />
    </Routes>
  )
}
