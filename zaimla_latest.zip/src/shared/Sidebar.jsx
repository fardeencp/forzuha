import { NavLink } from 'react-router-dom'

export default function Sidebar(){
  return (
    <aside className="w-64 p-4 bg-[#041028] min-h-screen">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded bg-gradient-to-br from-zaimla to-zaimla-accent flex items-center justify-center text-white font-bold">Z</div>
        <div className="text-white font-bold">Zaimla</div>
      </div>

      <nav className="flex flex-col gap-2 text-[#bcd8ff]">
        <NavLink to="/admin" className={({isActive})=> isActive ? 'px-3 py-2 rounded bg-[#082036]': 'px-3 py-2 rounded hover:bg-[#071427]'}>Dashboard</NavLink>
        <a className="px-3 py-2 rounded hover:bg-[#071427]">Projects</a>
        <a className="px-3 py-2 rounded hover:bg-[#071427]">Employees</a>
        <a className="px-3 py-2 rounded hover:bg-[#071427]">Documents</a>
        <a className="px-3 py-2 rounded hover:bg-[#071427]">Recruitment</a>
      </nav>
    </aside>
  )
}
