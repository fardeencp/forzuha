export default function Topbar(){
  return (
    <div className="flex items-center justify-between mb-6">
      <div className="flex items-center gap-3">
        <input placeholder="Search projects or people..." className="px-3 py-2 rounded w-80 bg-[#071427] text-[#cfe9ff] border border-transparent" />
      </div>
      <div className="flex items-center gap-3">
        <button className="px-3 py-2 rounded bg-[#06243b]">Notifications</button>
        <div className="px-3 py-2 rounded bg-[#06243b]">Admin</div>
      </div>
    </div>
  )
}
