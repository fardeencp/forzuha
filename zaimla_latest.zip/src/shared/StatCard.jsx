export default function StatCard({title,value}){
  return (
    <div className="p-4 rounded-lg bg-[#0b1a2a]">
      <div className="text-sm text-gray-400">{title}</div>
      <div className="text-2xl font-bold">{value}</div>
    </div>
  )
}
