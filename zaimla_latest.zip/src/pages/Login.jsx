import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

export default function Login(){
  const [email,setEmail]=useState('')
  const [pass,setPass]=useState('')
  const nav = useNavigate()

  function submit(e){
    e.preventDefault()
    // dummy auth: accept any credentials
    nav('/admin')
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="w-full max-w-md p-8 bg-white rounded-lg shadow">
        <h2 className="text-2xl mb-4">Admin Login</h2>
        <form onSubmit={submit} className="space-y-4">
          <input className="w-full p-3 border rounded" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
          <input className="w-full p-3 border rounded" placeholder="Password" type="password" value={pass} onChange={e=>setPass(e.target.value)} />
          <div className="flex justify-between items-center">
            <button className="px-4 py-2 bg-zaimla text-white rounded">Login</button>
            <button type="button" onClick={()=>nav('/')} className="text-sm text-gray-500">Back</button>
          </div>
        </form>
      </div>
    </div>
  )
}
