import Sidebar from '../shared/Sidebar'
import Topbar from '../shared/Topbar'
import StatCard from '../shared/StatCard'

const stats = [
  {title:'Employees', value:42},
  {title:'Projects', value:8},
  {title:'Documents', value:240},
  {title:'Open Vacancies', value:3},
]

export default function Admin(){
  return (
    <div className="min-h-screen admin-body flex">
      <Sidebar />
      <div className="flex-1 p-6">
        <Topbar />
        <h2 className="text-2xl font-semibold mb-4">Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {stats.map(s=> <StatCard key={s.title} title={s.title} value={s.value} />)}
        </div>

        <section className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="p-4 bg-[#0b1a2a] rounded-lg">
            <h3 className="font-semibold mb-2">Project Progress</h3>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-sm mb-1"><span>Project A</span><span>65%</span></div>
                <div className="w-full bg-[#071022] rounded h-3">
                  <div className="h-3 rounded" style={{width:'65%', background:'linear-gradient(90deg,#00e5ff,#0052cc)'}}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1"><span>Project B</span><span>40%</span></div>
                <div className="w-full bg-[#071022] rounded h-3">
                  <div className="h-3 rounded" style={{width:'40%', background:'linear-gradient(90deg,#00e5ff,#0052cc)'}}></div>
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 bg-[#0b1a2a] rounded-lg">
            <h3 className="font-semibold mb-2">Recent Applicants</h3>
            <ul className="text-sm space-y-2">
              <li>Ravi Kumar — Interview Scheduled</li>
              <li>Meera S — Under Review</li>
              <li>Arjun P — Rejected</li>
            </ul>
          </div>

          <div className="p-4 bg-[#0b1a2a] rounded-lg">
            <h3 className="font-semibold mb-2">Quick Actions</h3>
            <div className="flex flex-col gap-2">
              <button className="px-3 py-2 rounded bg-zaimla text-white">Add Project</button>
              <button className="px-3 py-2 rounded border">Upload Document</button>
              <button className="px-3 py-2 rounded border">Post Vacancy</button>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}
