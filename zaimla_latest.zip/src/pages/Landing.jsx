import { useNavigate } from 'react-router-dom'

export default function Landing(){
  const nav = useNavigate()
  return (
    <div className="min-h-screen flex flex-col">
      <header className="flex items-center justify-between p-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-zaimla to-zaimla-accent flex items-center justify-center text-white font-bold">Z</div>
          <h1 className="text-2xl font-semibold">Zaimla</h1>
        </div>
        <nav className="space-x-4">
          <button onClick={()=>nav('/careers')} className="px-4 py-2 rounded-md">Careers</button>
          <button onClick={()=>nav('/login')} className="px-4 py-2 rounded-md bg-zaimla text-white">Admin Login</button>
        </nav>
      </header>

      <main className="flex-1 flex items-center justify-center">
        <section className="max-w-4xl text-center p-8">
          <h2 className="text-4xl font-bold mb-4">Digitize Zaimla — Projects, People & Processes</h2>
          <p className="mb-6 text-gray-600">A single platform for clients, employees and HR to manage projects, documents and recruitment.</p>
          <div className="flex justify-center gap-4 mb-8">
            <button onClick={()=>nav('/careers')} className="px-6 py-3 rounded-md border">Explore Careers</button>
            <button onClick={()=>nav('/login')} className="px-6 py-3 rounded-md bg-zaimla text-white">Admin Login</button>
            <button onClick={()=>nav('/admin')} className="px-6 py-3 rounded-md ring-2 ring-zaimla-accent text-zaimla">Quick Admin</button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-6">
            <div className="p-4 border rounded-lg">
              <h3 className="font-semibold">Projects</h3>
              <p className="text-sm text-gray-500">Track milestones & progress</p>
            </div>
            <div className="p-4 border rounded-lg">
              <h3 className="font-semibold">Careers</h3>
              <p className="text-sm text-gray-500">Open positions & applications</p>
            </div>
            <div className="p-4 border rounded-lg">
              <h3 className="font-semibold">Clients</h3>
              <p className="text-sm text-gray-500">Project access & deliverables</p>
            </div>
            <div className="p-4 border rounded-lg">
              <h3 className="font-semibold">Documents</h3>
              <p className="text-sm text-gray-500">Centralized document repository</p>
            </div>
          </div>
        </section>
      </main>

      <footer className="p-6 text-center text-sm text-gray-500">© {new Date().getFullYear()} Zaimla — All rights reserved</footer>
    </div>
  )
}
