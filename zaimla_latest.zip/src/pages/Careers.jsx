import { useNavigate } from 'react-router-dom'

export default function Careers(){
  const nav = useNavigate()
  return (
    <div className="min-h-screen p-10 flex flex-col items-center justify-center">
      <h1 className="text-4xl font-semibold mb-4">Careers — Coming Soon</h1>
      <p className="text-gray-500 mb-6">We're building the Careers portal. Check back soon for job openings and application tracking.</p>
      <button onClick={()=>nav('/')} className="px-4 py-2 rounded border">Back to Home</button>
    </div>
  )
}
