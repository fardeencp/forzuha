module.exports = {
  content: [
    './index.html',
    './src/**/*.{js,jsx,ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        zaimla: {
          DEFAULT: '#0052CC',
          'accent': '#00E5FF',
          'dark': '#071025'
        }
      },
      fontFamily: {
        zaimla: ['Orbitron', 'ui-sans-serif', 'system-ui']
      }
    },
  },
  plugins: [],
}
